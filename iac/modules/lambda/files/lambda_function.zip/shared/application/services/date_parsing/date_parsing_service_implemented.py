from datetime import datetime, timezone

from shared.domain.services.date_parsing.date_parsing_service import DataParsingService


class SystemDateTimeServiceImplemented(DataParsingService):

    def utc_now_compact(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")

    def utc_now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat()


    def utc_now(self) -> datetime:
        return datetime.now(timezone.utc)

