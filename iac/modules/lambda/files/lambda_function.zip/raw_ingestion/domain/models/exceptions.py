class PartitionAlreadyCompletedException(Exception):
    pass
